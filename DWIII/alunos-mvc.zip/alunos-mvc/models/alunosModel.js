const alunos = [
    { nome: 'Daniela', idade: 17 },
    { nome: 'João', idade: 21 },
    { nome: 'Pedro', idade: 25 },
];

module.exports = alunos;